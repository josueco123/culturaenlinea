@extends('layouts.app')

{{-- Título de la página (Título único en cada página) con máximo 3 palabras clave (Palabra principal primero) y de máximo 70 catacteres --}}
@section ('page-title', 'Alcaldía de santiago de cali - Secretaría de cultura')

{{-- Descripción de la página (Descripción única en cada página) con máximo 3 palabras clave (Palabra principal primero) y entre 70 y 145 catacteres --}}
@section('page-description', 'Alcaldía de santiago de cali - Secretaría de cultura')

@section('content')

  <header class="home">
    <div class="container-fluid py-0 py-md-5">
      <div class="container py-4 py-md-5 h-100">
        <div class="row h-100 align-items-center">
          <div class="col">
            <h1 class="font-weight-bold display-3 text-white mt-5 mb-2">Sucural <br>en Movimiento</h1>
          </div>
        </div>
      </div>
    </div>
    <div class="container-fluid home-2">
      <div class="row py-5">
        <div class="col py-5">
        </div>
      </div>
    </div>
  </header>

<section class="py-0 pt-md-5">
  <div class="container pt-3">
    <div class="row align-items-xl-end align-items-md-end">
      <div class="col-12 col-lg-6">
        <img class="img-fluid" src="{{ asset('img/layout/la-cultura-de-cali.jpg') }}" alt="Convocatoria unidos por la vida">
      </div>
      <div class="col-12 col-lg-6 text-center text-lg-left pb-2">
        <h2 class="font-weight-bold display-4 mt-5 mb-4">La cultura de Cali <br>llega a lo digital</h2>
        <p>Este un espacio creado por la Secretaría de Cultura de Cali, que ante la difícil situación que vive el sector del arte, la cultura y la creatividad, se transforma para hacer uso de todas las plataformas digitales con el fin de generar mayor incidencia en la ciudad mostrando a Cali, La Sucursal en Movimiento nace como una estrategia de impulso y acción creativa e innovadora, para impulsar la cultura y de paso levantar el orgullo de la ciudad, reactivar el sector cultural y de paso impulsar la reactivación económica de la ciudad.</p>
        <p>Está pensada en tres (3) etapas:</p>
          
<p>1.	Pegáte al movimiento: Convoca a los artistas de la ciudad para participar en varias líneas de financiación de sus producciones artísticas: Estímulos, Concertación, Ley de Espectáculos públicos y plan de Choque de circulación. En esta primera etapa, los artistas podrán acceder a una especie de bolsa de recursos públicos que abarcarán a las distintas disciplinas del arte y la cultura </p>
          
        <p>2.	Cali Se Mueve: comenzarán a entregarse los resultados de las convocatorias, pero además se dará inicio al plan de circulación de choque, en el que artistas de la ciudad tendrán presentaciones garantizadas en centros comerciales, restaurantes, hoteles, bares, y parques públicos de la ciudad.</p>
          
        <p>3.  Movéte que estamos en Festival será dedicada a la Temporada de Festivales de Cali. Conectar con el mundo desde la oferta cultural de la ciudad y proporcionar un mensaje de confianza y de apropiación biosegura de los espacios culturales. Aporta a la reactivación económica del sector. </p>
      </div>
    </div>
  </div>
</section>

<section class="content__red py-5">
  <div class="container py-3 py-md-5">
    <div class="row justify-content-center">
      <div class="col-xl-8 py-md-5 text-light text-center">
        <h2 class="font-weight-bold display-4 mb-4">Plan de Reactivación Económica <br>del sector cultura "CALI SE MUEVE"</h2>
        <p class="mb-4">Es la segunda etapa del plan de choque para la circulación de los diferentes subsectores de las artes, la cultura y la creatividad. Para esto hemos desarrollado diferentes mecanismos y alianzas, con el sector público y el privado. permitiendo identificar diferentes acciones de corto, mediano y largo alcance.">Próximamente</a>
      </div>
    </div>
  </div>
</section>

<section class="py-0 py-md-5">
  <div class="container py-3">
    <div class="row align-items-center">
      <div class="col-12 col-lg-6 text-center text-lg-right">
        <h2 class="font-weight-bold display-4 mb-4">Convocatoria ‘Unidos por <br>la vida de los artistas’</h2>
        <p class="mb-4">La COVID-19 ha generado un impacto social, cultural y económico. Por esta razón se desarrollan estrategias y dinámicas de trabajo en conjunto que permita mitigar dicho impacto. Es por ello que se crea una alianza entre el Programa Estímulos y la Ley de Espectáculos Públicos, los cuales juntos crean una bolsa de 3.500 millones de pesos para atender al sector en proyectos, iniciativas y creaciones, todo esto con el fin de impulsar a que artistas, y gestores puedan iniciar labores y superar la crisis que
dejará esta emergencia sanitaria.</p>
        <a href="{{ route('frontend.calls.call', ['slug' =>'convocatoria-unidos-por-la-vida-2020']) }}" class="btn btn-info btn-lg mb-5 mb-lg-0">Ver convocatorias</a>
      </div>
      <div class="col-12 col-lg-6 text-center">
        <img class="img-fluid" src="{{ asset('img/layout/unidos-por-la-vida-2020.jpg') }}" alt="Convocatoria unidos por la vida">
      </div>
    </div>
  </div>
</section>

<section class="content__blue py-0 py-md-5">
  <div class="container py-3">
    <div class="row align-items-center">
      
      <div class="col-12 col-lg-6 py-5">
        <img class="img-fluid" src="{{ asset('img/layout/cultura-en-linea.png') }}" alt="Convocatoria unidos por la vida">
      </div>
      <div class="col-12 col-lg-6 text-center text-lg-left text-light">
        <h2 class="font-weight-bold display-4 mb-4">Estrategias <br>que nos conectan</h2>
        <p class="mb-4">Cultura Viral, nace como una estrategia de circulación y visibilización para los artistas, consolidándose como un programa online transmitido por el fan page de la Secretaría de Cultura, el cual cuenta con contenidos culturales, pedagógicos, artísticos y de memoria en el marco de las estrategias de prevención propuestas por la Alcaldía de Santiago de Cali.</p>
 
<p>Como plataforma de contenidos, Cultura Viral  es un espacio solidario en el que los artistas pueden elevar su voz en favor de una causa común, donde ellos desde su lenguaje artístico pueden llegar a las comunidades a enviar mensajes de prevención, para así mitigar las secuelas de la crisis actual y continuar conectados al público. </p>
      </div>
    </div>
  </div>
</section>



@endsection

@section('script')

  <script type="text/javascript">

      $('[data-toggle="popover"]').popover();

  </script>

@endsection
