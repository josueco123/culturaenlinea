<footer class="py-5 bg-white border-top">

  <div class="container">

    <div class="row">
      <div class="col-12 col-md text-center text-md-left">
        <h4>Centro Cultural de Cali</h4>
        <ul class="list-unstyled">
          <li>Carrera 5 # 6 - 05</li>
          <li>8858855</li>
          <li>Cali - Colombia</li>
        </ul>
      </div>
      <div class="col-12 col-md-auto text-center">
        <img class="mb-4 mb-md-0" src="{{ asset('img/layout/logos.jpeg') }}" alt="Alcaldía de cali">
      </div>
      <div class="col-12 text-center">
        <span class=" text-center text-muted">Secretaría de Cultura <span class="d-none d-sm-inline">|</span> <br class="d-block d-sm-none">Alcaldía de Santiago de Cali<br/> Todos los derechos reservados © {{ date('Y') }} </span>
      </div>
    </div>

  </div>

</footer>
